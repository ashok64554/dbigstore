import { FileSizeFormatPipe } from './file-size-format.pipe';

describe('FileSizeFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new FileSizeFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
